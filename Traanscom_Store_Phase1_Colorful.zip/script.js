const products=[
{id:1,name:"Classic Everyday Sneakers",cat:"Fashion",price:6499,old:7999,emoji:"👟",tag:"SALE",desc:"Comfortable everyday sneakers with a clean, versatile design."},
{id:2,name:"Wireless Headphones",cat:"Electronics",price:8999,old:10999,emoji:"🎧",tag:"POPULAR",desc:"Immersive sound, comfortable fit and wireless freedom."},
{id:3,name:"Smart Watch Pro",cat:"Electronics",price:12499,old:14999,emoji:"⌚",tag:"NEW",desc:"A modern smartwatch for everyday activity and notifications."},
{id:4,name:"Premium Skin Care Set",cat:"Beauty",price:4599,old:5299,emoji:"🧴",tag:"NEW",desc:"A simple daily care set designed for a fresh routine."},
{id:5,name:"Minimal Desk Lamp",cat:"Home & Living",price:3499,old:4299,emoji:"💡",tag:"SALE",desc:"Minimal lighting for desks, bedrooms and reading corners."},
{id:6,name:"Travel Backpack",cat:"Accessories",price:5799,old:6999,emoji:"🎒",tag:"POPULAR",desc:"Spacious everyday backpack for work, study and travel."},
{id:7,name:"Classic Sunglasses",cat:"Accessories",price:2999,old:3999,emoji:"🕶️",tag:"SALE",desc:"Timeless sunglasses with a lightweight everyday frame."},
{id:8,name:"Home Aroma Diffuser",cat:"Home & Living",price:3999,old:4999,emoji:"🪴",tag:"NEW",desc:"Create a relaxing atmosphere with this compact diffuser."},
{id:9,name:"Cotton Casual Shirt",cat:"Fashion",price:3199,old:3899,emoji:"👕",tag:"NEW",desc:"Soft casual shirt designed for comfortable daily wear."},
{id:10,name:"Portable Speaker",cat:"Electronics",price:4999,old:5999,emoji:"🔊",tag:"POPULAR",desc:"Compact wireless speaker for music at home or outdoors."},
{id:11,name:"Everyday Tote Bag",cat:"Accessories",price:2499,old:2999,emoji:"👜",tag:"SALE",desc:"A practical tote with room for your everyday essentials."},
{id:12,name:"Body Care Essentials",cat:"Beauty",price:3799,old:4499,emoji:"🧼",tag:"NEW",desc:"A convenient set of everyday personal-care essentials."}
];
const cats=[["Fashion","👕"],["Electronics","🎧"],["Beauty","🧴"],["Home & Living","🏠"],["Accessories","👜"],["Health & Care","✨"]];
let cart=JSON.parse(localStorage.getItem("traanscomCart")||"[]");

const money=n=>"Rs. "+n.toLocaleString("en-PK");
const $=s=>document.querySelector(s);

function renderCategories(){
  $("#categoryGrid").innerHTML=cats.map(([name,emoji])=>`<div class="category" data-cat="${name}"><span class="emoji">${emoji}</span><b>${name}</b></div>`).join("");
  document.querySelectorAll(".category").forEach(x=>x.onclick=()=>{ $("#categoryFilter").value=x.dataset.cat; renderProducts(); location.hash="shop";});
  $("#categoryFilter").innerHTML='<option value="all">All categories</option>'+cats.map(c=>`<option>${c[0]}</option>`).join("");
}
function renderProducts(){
  const q=$("#searchInput").value.toLowerCase().trim(), cat=$("#categoryFilter").value;
  const list=products.filter(p=>(cat==="all"||p.cat===cat)&&(!q||p.name.toLowerCase().includes(q)||p.cat.toLowerCase().includes(q)));
  $("#productGrid").innerHTML=list.map(p=>`<article class="product" data-id="${p.id}"><div class="product-image"><span class="tag">${p.tag}</span><span class="emoji">${p.emoji}</span></div><div class="product-info"><h3>${p.name}</h3><p>${p.cat}</p><p class="price">${money(p.price)}</p></div></article>`).join("");
  $("#emptyState").hidden=list.length>0;
  document.querySelectorAll(".product").forEach(x=>x.onclick=()=>openProduct(+x.dataset.id));
}
function openProduct(id){
  const p=products.find(x=>x.id===id);
  $("#modalContent").innerHTML=`<div class="modal-product"><div class="modal-img">${p.emoji}</div><div><p class="eyebrow">${p.cat}</p><h2>${p.name}</h2><p class="price">${money(p.price)}</p><p class="desc">${p.desc}</p><p>✓ In stock &nbsp; ✓ Secure checkout</p><button class="btn primary" onclick="addToCart(${p.id});closeProduct()">Add to Cart</button></div></div>`;
  $("#productModal").classList.add("open"); $("#overlay").classList.add("show");
}
function closeProduct(){ $("#productModal").classList.remove("open"); $("#overlay").classList.remove("show");}
function addToCart(id){
  const found=cart.find(x=>x.id===id); found?found.qty++:cart.push({id,qty:1});
  saveCart(); toast("Added to cart");
}
function saveCart(){localStorage.setItem("traanscomCart",JSON.stringify(cart));renderCart();}
function renderCart(){
  $("#cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0);
  if(!cart.length){$("#cartItems").innerHTML='<p class="empty">Your cart is empty.</p>';$("#cartTotal").textContent=money(0);return;}
  $("#cartItems").innerHTML=cart.map(x=>{const p=products.find(z=>z.id===x.id);return `<div class="cart-row"><div class="cart-thumb">${p.emoji}</div><div><h4>${p.name}</h4><p>${money(p.price)}</p><div class="qty"><button onclick="changeQty(${p.id},-1)">−</button><span>${x.qty}</span><button onclick="changeQty(${p.id},1)">+</button></div></div><b>${money(p.price*x.qty)}</b></div>`}).join("");
  $("#cartTotal").textContent=money(cart.reduce((a,x)=>a+products.find(p=>p.id===x.id).price*x.qty,0));
}
function changeQty(id,d){const x=cart.find(a=>a.id===id);x.qty+=d;if(x.qty<=0)cart=cart.filter(a=>a.id!==id);saveCart();}
function openCart(){$("#cartDrawer").classList.add("open");$("#overlay").classList.add("show")}
function closeCart(){$("#cartDrawer").classList.remove("open");$("#overlay").classList.remove("show")}
function toast(msg){$("#toast").textContent=msg;$("#toast").classList.add("show");setTimeout(()=>$("#toast").classList.remove("show"),1600)}
$("#searchInput").oninput=renderProducts;$("#categoryFilter").onchange=renderProducts;
$("#cartBtn").onclick=openCart;$("#closeCart").onclick=closeCart;$("#closeModal").onclick=closeProduct;$("#overlay").onclick=()=>{closeCart();closeProduct()};
$("#searchBtn").onclick=()=>{$("#searchInput").focus();location.hash="shop"};
$("#menuBtn").onclick=()=>$("#mobileNav").classList.toggle("show");
$("#checkoutBtn").onclick=()=>cart.length?toast("Checkout module will be connected in the next phase."):toast("Your cart is empty");
renderCategories();renderProducts();renderCart();
